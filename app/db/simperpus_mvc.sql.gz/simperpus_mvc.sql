-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2022 at 08:23 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simperpus_mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `isbn` varchar(15) DEFAULT NULL,
  `judul` varchar(150) DEFAULT NULL,
  `idpengarang` int(50) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `isbn`, `judul`, `idpengarang`, `stok`, `gambar`) VALUES
(1114, 'A001', 'Ngenest : Ngetawain Hidup A la Ernest', 1236, 25, 'ngenest.jpg'),
(1115, 'A002', 'Setengah Jalan', 1236, 30, 'setengah jalan.jpg'),
(1117, 'A003', 'Manusia Setengah Salmon', 1237, 40, 'manusia setengah salmon.jpg'),
(1118, 'A004', 'Hujan', 1238, 20, 'hujan.jpg'),
(1119, 'A005', 'Koala Kumal', 1237, 50, 'koala kumal.jpg'),
(1120, 'A006', 'Bumi', 1238, 76, 'bumi.jpg'),
(1121, 'A007', 'Marmut Merah Jambu', 1237, 68, 'marmut merah jambu.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cabang`
--

CREATE TABLE `cabang` (
  `id` int(10) NOT NULL,
  `kode_cabang` varchar(10) CHARACTER SET utf8 NOT NULL,
  `nama_cabang` varchar(200) CHARACTER SET utf8 NOT NULL,
  `alamat` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cabang`
--

INSERT INTO `cabang` (`id`, `kode_cabang`, `nama_cabang`, `alamat`) VALUES
(1, 'C001', 'Dipatiukur', 'Jl. Dipatiukur No. 114'),
(3, 'C003', 'Arcamanik', 'Jl. Arcamanik No.4'),
(4, 'C004', 'Cicadas', 'Jl. Ahmad Yani No.105'),
(5, 'C005', 'Sekeloa', 'Jl. Sekeloa No.10'),
(6, 'C006', 'Jatihandap', 'Jl. Jatihandap No. 20'),
(7, 'C007', 'Cimahi', 'Jl. Teknologi IV No. 2');

-- --------------------------------------------------------

--
-- Table structure for table `pengarang`
--

CREATE TABLE `pengarang` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengarang`
--

INSERT INTO `pengarang` (`id`, `nama`, `email`) VALUES
(1234, 'Faisal Hanif Arifin', 'faisal@gmail.com'),
(1236, 'Ernest Prakasa', 'ernest.prakasa@outlook.co'),
(1237, 'Raditya Dika', 'radit_yadika@gmail.com'),
(1238, 'Tere Liye', 'liye-tere@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id` int(10) NOT NULL,
  `idcabang` int(10) NOT NULL,
  `idbuku` int(10) NOT NULL,
  `jumlah` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_pengarang_buku` (`idpengarang`);

--
-- Indexes for table `cabang`
--
ALTER TABLE `cabang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengarang`
--
ALTER TABLE `pengarang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_buku_penjualan` (`idbuku`),
  ADD KEY `FK_cabang_penjualan` (`idcabang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1122;

--
-- AUTO_INCREMENT for table `cabang`
--
ALTER TABLE `cabang`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pengarang`
--
ALTER TABLE `pengarang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1239;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `FK_pengarang_buku` FOREIGN KEY (`idpengarang`) REFERENCES `pengarang` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `FK_buku_penjualan` FOREIGN KEY (`idbuku`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_cabang_penjualan` FOREIGN KEY (`idcabang`) REFERENCES `cabang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
